package juego.modelo;

public abstract class Personaje {

    protected String nombre;
    protected int vida;
    protected int ataque;
    protected int defensa;
    protected int nivel;
    protected String tipo;
    protected int energia;
    protected int maxEnergia = 100;
    protected int cooldown = 0;
    protected String estado = "Normal";
    protected Objeto obj;

    public Personaje(String nombre, int vida, int ataque, int defensa, String tipo, Objeto obj) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = (ataque + obj.getAtq());
        this.defensa = (defensa + obj.getDef());
        this.tipo = tipo;
        this.obj = obj;
        this.nivel = (int)(Math.random() * 100) + 1;
        this.energia = maxEnergia;
    }

    public abstract int atacar();

    public void defender(int danio) {
        int danioFinal = danio - defensa - obj.getDef();
        if (danioFinal < 0){
            danioFinal = 0;
        }
        vida -= danioFinal;
    }

    public int usarHabilidadEspecial() throws Exception {
        if (energia < 20) throw new Exception("sin energia");
        if (cooldown > 0) throw new Exception("en cooldown");

        energia -= 20;
        cooldown = 2;

        return habilidadEspecial();
    }

    protected abstract int habilidadEspecial();

    public void reducirCooldown() {
        if (cooldown > 0) cooldown--;
    }

    public void aplicarEstado(String e) { estado = e; }
    public String getEstado() { return estado; }

    public void resetearEstado() {
        if (tipo.equals("Guerrero")) vida = 100;
        else if (tipo.equals("Mago")) vida = 80;
        else vida = 90;

        energia = maxEnergia;
        cooldown = 0;
        estado = "Normal";
    }

    public String getNombre() { return nombre; }
    public int getVida() { return vida; }
    public int getCooldown() { return cooldown; }
    
    @Override
    public String toString() {
        return nombre + " [" + tipo + "]" +
               " | Vida: " + vida +
               " | Nivel: " + nivel +
               " | Ataque: " + ataque +
               " | Defensa: " + defensa +
               " | Energia: " + energia +
               " | Objeto: " + obj.getNombre() + 
               " [" + obj.getTipo() + "]";
    }
}