package juego.modelo;

public class Combate {

    public Personaje pelear(Personaje p1, Personaje p2) {

        System.out.println("\n--- COMBATE ---");
        System.out.println(p1);
        System.out.println(p2);

        while (p1.getVida() > 0 && p2.getVida() > 0) {

            String e1 = (p1.getCooldown() == 0) ? "HABILIDAD CARGADA" : "EN ESPERA";
            String e2 = (p2.getCooldown() == 0) ? "HABILIDAD CARGADA" : "EN ESPERA";

            System.out.println("\nEstado:");
            System.out.println(p1.getNombre() + " | " + e1 + " | Estado: " + p1.getEstado());
            System.out.println(p2.getNombre() + " | " + e2 + " | Estado: " + p2.getEstado());

            int d1;
            try {
                d1 = (p1.getCooldown()==0)?p1.usarHabilidadEspecial():p1.atacar();
                System.out.println(p1.getNombre()+" ataca con "+d1);
            } catch(Exception e){
                d1 = p1.atacar();
            }

            p2.defender(d1);
            System.out.println("Vida de "+p2.getNombre()+": "+p2.getVida());

            if (Math.random()<0.3){
                p2.aplicarEstado("Quemado 🔥");
                System.out.println(p2.getNombre()+" ahora está: Quemado 🔥");
            }

            if (p2.getVida()==0) return p1;

            int d2;
            try {
                d2 = (p2.getCooldown()==0)?p2.usarHabilidadEspecial():p2.atacar();
                System.out.println(p2.getNombre()+" ataca con "+d2);
            } catch(Exception e){
                d2 = p2.atacar();
            }

            p1.defender(d2);
            System.out.println("Vida de "+p1.getNombre()+": "+p1.getVida());

            if (p1.getVida()==0) return p2;

            p1.reducirCooldown();
            p2.reducirCooldown();
        }
        return null;
    }
}