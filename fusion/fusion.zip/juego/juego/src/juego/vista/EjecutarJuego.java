package juego.vista;

import juego.controlador.ControladorJuego;

public class EjecutarJuego {
    public static void main(String[] args) {
        new ControladorJuego().run();
    }
}