package juego.controlador;

import juego.modelo.*;
import java.util.Random;

public class ControladorJuego {

    public void run() {

        Random rand = new Random();

        Personaje[] personajes = {
            new Guerrero("Kratos"),
            new Mago("Gandalf"),
            new Arquero("Legolas")
        };

        Personaje p1 = personajes[rand.nextInt(personajes.length)];
        Personaje p2 = personajes[rand.nextInt(personajes.length)];

        while (p1 == p2)
            p2 = personajes[rand.nextInt(personajes.length)];

        p1.resetearEstado();
        p2.resetearEstado();

        Combate combate = new Combate();
        Personaje ganador = combate.pelear(p1, p2);

        System.out.println("\nGANADOR: " + (ganador != null ? ganador.getNombre() : "EMPATE"));
    }
}